(function() {
  this.require(rails - ujs);

  this.require(jquery3);

  this.require(popper);

  this.require(bootstrap);

  this.require(turbolinks);

  this.require(cable);

}).call(this);
